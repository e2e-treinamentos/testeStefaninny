package br.com.e2etreinamentos.apie2etreinamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiE2etreinamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiE2etreinamentosApplication.class, args);
	}

}
