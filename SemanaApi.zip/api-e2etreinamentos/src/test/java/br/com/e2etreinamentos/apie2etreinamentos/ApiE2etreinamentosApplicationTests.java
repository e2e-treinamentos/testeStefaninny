package br.com.e2etreinamentos.apie2etreinamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiE2etreinamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
